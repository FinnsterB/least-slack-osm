# least-slack-osm
Implementation of a least-slack scheduler in C++.
